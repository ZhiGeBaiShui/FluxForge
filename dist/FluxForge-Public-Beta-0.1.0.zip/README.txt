FluxForge - Public Beta 0.1.0
Probably Stolen 0.46

========================================
内测交流 QQ 群：568324459
QQ GROUP: 568324459
========================================

【安装方法】
1. 退出游戏，并备份准备使用的存档。
2. 找到游戏安装目录。在 Steam 中右键游戏 -> 管理 -> 浏览本地文件。
3. 将本压缩包中的整个 FluxForge 文件夹复制到游戏目录的 Mods 文件夹。
   如果没有 Mods 文件夹，可自行创建。
4. 启动游戏，确认模组已加载。

正确的目录结构：
Probably Stolen/
  Mods/
    FluxForge/
      FluxForge.dll
      manifest.xml
      Textures/
        npc_saleswoman.png
        Items/
          ...

请保留整个 Textures 文件夹，不要只复制 DLL。
不要多套一层文件夹，例如 Mods/FluxForge/FluxForge/FluxForge.dll。
本 Mod 使用游戏官方 ModLoader；不需要为它额外安装 MelonLoader。
更新前请退出游戏，用新版文件替换原有 Mods/FluxForge 文件夹中的对应文件。

【开始体验】
商人奥雅会带着装置、商品与演示到访。通过对话了解玩法并获取装置。
将液体装入发射器，组合过滤、温控、冷萃、变速和转向装置，搭建处理路线。
可降低酸、碱等液体中的化学污染和重金属污染；冷萃可用于极少量成分微调。
冷萃选择含量最低的非零液体成分，请留意实际液体组成。

【内测反馈】
欢迎加入 QQ 群 568324459，反馈报错、剧情、美术、玩法体验和新想法。
反馈异常时请尽量提供游戏/Mod 版本、操作步骤、截图或日志。
贴图与立绘主要使用 AI 生成并人工修图，欢迎美术建议和画师合作。

========================================
ENGLISH INSTALLATION
========================================
Requires Probably Stolen 0.46 and its built-in ModLoader.

1. Close the game and back up your save.
2. Open the game installation folder.
   Steam: right-click the game -> Manage -> Browse local files.
3. Copy the entire FluxForge folder from this archive into the game's Mods folder.
   Create Mods if it does not exist.
4. Launch the game and check that the mod has loaded.

Correct path: Mods/FluxForge/FluxForge.dll
manifest.xml and the complete Textures folder must be beside the DLL.
Do not create an extra nested FluxForge folder. Do not copy only the DLL.
This mod uses the official built-in ModLoader; MelonLoader is not required.
Close the game before replacing files when updating.

GETTING STARTED
The merchant 奥雅 visits with devices, goods and demonstrations.
Use emitters and processing devices to build liquid-processing routes in your inventory.
Filters reduce chemical and heavy-metal contamination; extraction can help fine-tune mixtures.
Extraction targets the smallest non-zero liquid component, so check the mixture first.

FEEDBACK
QQ GROUP: 568324459
Please include game/mod versions, reproduction steps, screenshots or logs when reporting issues.
Textures and portraits are primarily AI-generated with manual edits. Artist collaboration is welcome.
