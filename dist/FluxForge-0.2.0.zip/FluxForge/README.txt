﻿FluxForge 0.2.0

本版启用流源和装置位置诊断。复现后提供游戏 Player.log 和操作步骤。F8 可追加记录现场。
